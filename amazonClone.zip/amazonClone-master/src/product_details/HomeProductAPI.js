const Data =[
    {
        id: 1,
        title: 'Acer Predator X35 10800R Curved 35 Inch UltraWide QHD Gaming Monitor',
        price: 184999.00,
        rating: 3,
        image: 'https://m.media-amazon.com/images/I/61M8j-hLncS._SL1500_.jpg'
    },
    {
        id: 2,
        title: 'ASUS TUF Gaming A15 (2021) 15.6-inch (39.62 cms) FHD 144Hz, AMD Ryzen 7 4800H, RTX 3050 4GB Graphics, Gaming Laptop',
        price: 74990.00,
        rating: 4,
        image: 'https://m.media-amazon.com/images/I/91zVSkGGZbS._SL1500_.jpg',
    },
    {
        id: 3,
        title: 'Omen by Hp Sequencer Wired USB Mechanical Optical Gaming Keyboard',
        price: 28097.00,
        rating: 4,
        image: 'https://m.media-amazon.com/images/I/71hJhJPDU4L._SL1500_.jpg'
    },
    {
        id: 4,
        title: '2021 Apple iPad Pro with Apple M1 chip (11-inch/27.96 cm, Wi-Fi + Cellular, 256GB)',
        price: 94900.00,
        rating: 4,
        image: 'https://m.media-amazon.com/images/I/81a-rN2A3DS._SL1500_.jpg'
    },{
        id: 5,
        title: 'Pulse Gaming Racing Edition GT-06 Ergonomic Gaming Chair (Black+Red)',
        price: 13499.00,
        rating: 4,
        image: 'https://m.media-amazon.com/images/I/71hkDz8ZefL._SL1500_.jpg'
    },{
        id: 6,
        title: 'HyperX Streamer Starter Pack (HBNDL0001)',
        price: 11490.00,
        rating: 4,
        image: 'https://m.media-amazon.com/images/I/71hRxXqRniL._SL1500_.jpg'
    },{
        id: 7,
        title: 'OnePlus 108 cm (43 inches) Y Series Full HD LED Smart Android TV 43Y1 (Black) (2020 Model)',
        price: 26999.00,
        rating: 4,
        image: 'https://m.media-amazon.com/images/I/71vZLIfj5yS._SL1500_.jpg'
    },
]

export default Data;